rsconnect::deployApp(
  rprojroot::find_package_root_file("inst/examples/flights"),
  appName = "flights",
  account = "bslib",
  forceUpdate = TRUE
)
